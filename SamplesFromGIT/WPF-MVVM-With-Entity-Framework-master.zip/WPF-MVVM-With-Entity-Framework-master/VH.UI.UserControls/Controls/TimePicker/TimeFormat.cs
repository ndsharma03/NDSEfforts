﻿
namespace VH.UI.UserControls.Controls
{
  public enum TimeFormat
  {
    Custom,
    ShortTime,
    LongTime
  }
}
