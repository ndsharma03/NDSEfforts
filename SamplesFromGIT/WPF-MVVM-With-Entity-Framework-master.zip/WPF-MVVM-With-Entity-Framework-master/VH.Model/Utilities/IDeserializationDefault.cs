﻿namespace VH.Model.Utilities
{
    public interface IDeserializationDefault
    {
        void SetDeserializationDefault();
    }
}
