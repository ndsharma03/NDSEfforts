﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Widget.Weather
{
    public enum TemperatureScale
    {
        Null = -1,
        Fahrenheit = 0,
        Celsius = 1
    }
}
