﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Widget.Weather
{
    public class HourForecastData
    {
        public string Temperature { get; set; }

        public string Time { get; set; }

        public int Precipitation { get; set; }
    }
}
