﻿using System.Windows.Controls;

namespace VH.View
{
    /// <summary>
    /// Interaction logic for ReminderView.xaml
    /// </summary>
    public partial class ReminderView : UserControl
    {
        public ReminderView()
        {
            InitializeComponent();
        }
    }
}
