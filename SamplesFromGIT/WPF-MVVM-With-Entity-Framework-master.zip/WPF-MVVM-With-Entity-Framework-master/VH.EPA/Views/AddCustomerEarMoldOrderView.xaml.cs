﻿using System.Windows.Controls;

namespace VH.View
{
    /// <summary>
    /// Interaction logic for AddEarMoldOrderView.xaml
    /// </summary>
    public partial class AddCustomerEarMoldOrderView : UserControl
    {
        public AddCustomerEarMoldOrderView()
        {
            InitializeComponent();
        }
    }
}
