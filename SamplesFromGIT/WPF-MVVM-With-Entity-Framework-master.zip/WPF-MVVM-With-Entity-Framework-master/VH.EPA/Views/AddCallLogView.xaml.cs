﻿using System.Windows.Controls;

namespace VH.View
{
    /// <summary>
    /// Interaction logic for AddCallLogView.xaml
    /// </summary>
    public partial class AddCallLogView : UserControl
    {
        public AddCallLogView()
        {
            InitializeComponent();
        }
    }
}
