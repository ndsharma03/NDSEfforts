﻿using System.Windows.Controls;

namespace VH.View
{
    /// <summary>
    /// Interaction logic for CallRegistryView.xaml
    /// </summary>
    public partial class CallRegistryView : UserControl
    {
        public CallRegistryView()
        {
            InitializeComponent();
        }
    }
}
