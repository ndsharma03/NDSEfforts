﻿using System.Windows.Controls;

namespace VH.View
{
    /// <summary>
    /// Interaction logic for CustomerWarrantyInformedView.xaml
    /// </summary>
    public partial class CustomerWarrantyInformedView : UserControl
    {
        public CustomerWarrantyInformedView()
        {
            InitializeComponent();
        }
    }
}
