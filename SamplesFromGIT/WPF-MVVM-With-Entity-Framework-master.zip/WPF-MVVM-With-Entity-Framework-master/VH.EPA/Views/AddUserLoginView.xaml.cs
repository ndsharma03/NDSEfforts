﻿using System.Windows.Controls;

namespace VH.View
{
    /// <summary>
    /// Interaction logic for AddUserLoginView.xaml
    /// </summary>
    public partial class AddUserLoginView : UserControl
    {
        public AddUserLoginView()
        {
            InitializeComponent();
        }
    }
}
