﻿using System.Windows.Controls;

namespace VH.View
{
    /// <summary>
    /// Interaction logic for AddCustomerWarrantyInformedView.xaml
    /// </summary>
    public partial class AddCustomerWarrantyInformedView : UserControl
    {
        public AddCustomerWarrantyInformedView()
        {
            InitializeComponent();
        }
    }
}
