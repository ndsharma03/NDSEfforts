﻿using System.Windows.Controls;


namespace VH.View
{
    /// <summary>
    /// Interaction logic for UpdateCustomerRepairStatus.xaml
    /// </summary>
    public partial class UpdateCustomerRepairStatusView : UserControl
    {
        public UpdateCustomerRepairStatusView()
        {
            InitializeComponent();
        }
    }
}
