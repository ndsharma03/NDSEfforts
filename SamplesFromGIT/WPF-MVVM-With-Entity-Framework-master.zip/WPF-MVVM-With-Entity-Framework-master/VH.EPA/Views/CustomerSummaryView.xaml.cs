﻿using System.Windows.Controls;

namespace VH.View
{
    /// <summary>
    /// Interaction logic for CustomerSummaryView.xaml
    /// </summary>
    public partial class CustomerSummaryView : UserControl
    {
        public CustomerSummaryView()
        {
            InitializeComponent();
        }
    }
}
