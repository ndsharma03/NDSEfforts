﻿using System.Windows.Controls;

namespace VH.View
{
    /// <summary>
    /// Interaction logic for AddHearingAidOrderView.xaml
    /// </summary>
    public partial class AddCustomerHearingAidOrderView : UserControl
    {
        public AddCustomerHearingAidOrderView()
        {
            InitializeComponent();
        }
    }
}
