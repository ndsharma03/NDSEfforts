﻿using System.Windows.Controls;

namespace VH.View
{
    /// <summary>
    /// Interaction logic for MiscellaneousView.xaml
    /// </summary>
    public partial class MiscellaneousView : UserControl
    {
        public MiscellaneousView()
        {
            InitializeComponent();
        }
    }
}
