﻿using System.Windows.Controls;

namespace VH.View
{
    /// <summary>
    /// Interaction logic for AddCustomerRepairView.xaml
    /// </summary>
    public partial class AddCustomerRepairView : UserControl
    {
        public AddCustomerRepairView()
        {
            InitializeComponent();
        }
    }
}
