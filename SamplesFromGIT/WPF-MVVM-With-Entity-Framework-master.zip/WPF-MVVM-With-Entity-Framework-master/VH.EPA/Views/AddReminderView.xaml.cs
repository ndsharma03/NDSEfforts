﻿using System.Windows.Controls;

namespace VH.View
{
    /// <summary>
    /// Interaction logic for AddReminderView.xaml
    /// </summary>
    public partial class AddReminderView : UserControl
    {
        public AddReminderView()
        {
            InitializeComponent();
        }
    }
}
