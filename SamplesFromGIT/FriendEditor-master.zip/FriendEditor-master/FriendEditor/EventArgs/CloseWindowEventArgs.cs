﻿namespace FriendEditor.EventArgs
{
    public class CloseWindowEventArgs
    {
    }
}